const modalCreateUp = () => {
    var modalCreate = document.getElementById("modal-create");
    modalCreate.style.visibility = "visible";
};
const modalUpdateUp = () => {
    var modalUpdate = document.getElementById("modal-update");
    modalUpdate.style.visibility = "visible";
};
const modalDeleteUp = () => {
    var modalDelete = document.getElementById("modal-delete");
    modalDelete.style.visibility = "visible";
};
const modalViewUp = () => {
    var modalView = document.getElementById("modal-view");
    modalView.style.visibility = "visible";
};
const closeModalCreate = () => {
    var modalCreate = document.getElementById("modal-create");
    modalCreate.style.visibility = "hidden";
};
const closeModalUpdate = () => {
    var modalUpdate = document.getElementById("modal-update");
    modalUpdate.style.visibility = "hidden";
};
const closeModalDelete = () => {
    var modalDelete = document.getElementById("modal-delete");
    modalDelete.style.visibility = "hidden";
};
const closeModalView = () => {
    var modalView = document.getElementById("modal-view");
    modalView.style.visibility = "hidden";
};

// // Modal Trigger
// var modalCreateTrigger = document.getElementById("modal-create-trigger");
// var modalUpdateTrigger = document.getElementById("modal-update-trigger");
// var modalDeleteTrigger = document.getElementById("modal-delete-trigger");
// // Modal Close
// var modalAddClose = document.getElementById("modal-add-close");
// var modalUpdateClose = document.getElementById("modal-update-close");
// var modalDeleteClose = document.getElementById("modal-delete-close");
// // Modal Form
// var modalCreate = document.getElementById("modal-create");
// var modalUpdate = document.getElementById("modal-update");
// var modalDelete = document.getElementById("modal-delete");

// // Modal Trigger Function
// modalCreateTrigger.addEventListener("click", function () {
//     modalCreate.style.visibility = "visible";
// });
// modalUpdateTrigger.addEventListener("click", function () {
//     modalUpdate.style.visibility = "visible";
// });
// modalDeleteTrigger.addEventListener("click", function () {
//     modalDelete.style.visibility = "visible";
// });

// // Modal Close
// modalAddClose.addEventListener("click", function () {
//     modalCreate.style.visibility = "hidden";
// });
// modalUpdateClose.addEventListener("click", function () {
//     modalUpdate.style.visibility = "hidden";
// });
// modalDeleteClose.addEventListener("click", function () {
//     modalDelete.style.visibility = "hidden";
// });
